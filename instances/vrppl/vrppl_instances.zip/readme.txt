<number of customers>	<number of lockers>
<number of vehicles>	<vehicle's capacity>
<demand>
<x-coord>	<ycoord>	<earliest>	<latest>	<service time>	<customer type>
<assigned locker box>

<customer type>
1 -> home delivery
2 -> parcel locker delivery
3 -> home/parcel locker delivery

example for <assigned locker box>:
1	0	0	0	0 -> this customer's package could be placed to the first locker box
0	0	0	0	0 -> this customer belongs to home delivery